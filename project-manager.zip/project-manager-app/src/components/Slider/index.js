// Esto es para importar el Slider sin poner en App.js Slider/Slider.
import Slider from "./Slider";
export default Slider;
