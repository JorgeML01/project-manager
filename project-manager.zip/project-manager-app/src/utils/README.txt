-El archivo services yo lo implementé de otra forma.
-El validator sí es recomendable usarlo para el frontend y así no tiene que irse al backend
 para hacer esa validación.